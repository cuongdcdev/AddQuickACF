=== Plugin Name ===
Contributors: CuongDC
Tags: AddQuickTag, ACF Pro 
Requires at least: 3.0 
Tested up to: 4.8
Stable tag: pretty-stable
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://www.paypal.me/cuongdc


== Description ==

   This dead simple plugin makes AddQuickTags supports working with ACF Option page.

   It's add all custom Quick Tags in Text mode  of ACF's WYSISYG Editor.


== Installation ==

Unzip this folder and upload it to your WordPress plugin directory, active it and you are done

== Changelog ==

= 0.0.1 =
    
    Alphal version
